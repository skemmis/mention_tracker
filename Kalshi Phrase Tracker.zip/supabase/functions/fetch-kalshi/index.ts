import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

// Known ticker-to-name mappings (shared with discover-mentions)
const TICKER_NAME_MAP: Record<string, string> = {
  "60MIN": "60 Minutes",
  "ACOOPER": "Anderson Cooper",
  "ACKMAN": "Bill Ackman",
  "ALTHOFF": "Judson Althoff",
  "ALTMAN": "Sam Altman",
  "AMODEI": "Dario Amodei",
  "AOC": "Alexandria Ocasio-Cortez",
  "ARMSTRONG": "Brian Armstrong",
  "AWARD": "Awards Show",
  "BANNON": "Steve Bannon",
  "BARKLEY": "Charles Barkley",
  "BARR": "Bill Barr",
  "BELL": "Kristen Bell",
  "BENIOFF": "Marc Benioff",
  "BERNIE": "Bernie Sanders",
  "BESSENTMTP": "Scott Bessent",
  "BETO": "Beto O'Rourke",
  "BIDEN": "Joe Biden",
  "BONGINO": "Dan Bongino",
  "BUSH": "George W. Bush",
  "CANDEB": "Canadian Debate",
  "CARLSON": "Tucker Carlson",
  "CENA": "John Cena",
  "CFB": "College Football",
  "CMA": "CMA Awards",
  "COLBERT": "Stephen Colbert",
  "COMER": "James Comer",
  "CONAN": "Conan O'Brien",
  "CONGRESS": "Congress",
  "COOPER": "Anderson Cooper",
  "COSTA": "António Costa",
  "CROCKETT": "Jasmine Crockett",
  "CRUZ": "Ted Cruz",
  "CULTURE": "Culture",
  "CUOMO": "Chris Cuomo",
  "DESANTIS": "Ron DeSantis",
  "DILLON": "Luke Dillon",
  "DIMON": "Jamie Dimon",
  "DOGSHOW": "Dog Show",
  "DWTS": "Dancing with the Stars",
  "ELON": "Elon Musk",
  "FINK": "Larry Fink",
  "FOXNEWS": "Fox News",
  "FRANKLIN": "James Franklin",
  "FREY": "Jacob Frey",
  "FTN": "Face the Nation",
  "GAETZ": "Matt Gaetz",
  "GAMEDAY": "GameDay",
  "GLASER": "Nikki Glaser",
  "GOVERNOR": "Governor",
  "GREEN": "Josh Green",
  "GRIFFIN": "Ken Griffin",
  "HALEY": "Nikki Haley",
  "HARRISP": "Kamala Harris",
  "HART": "Kevin Hart",
  "HEGSETH": "Pete Hegseth",
  "HOCHUL": "Kathy Hochul",
  "HOMAN": "Tom Homan",
  "HUBERMAN": "Andrew Huberman",
  "INFANTINO": "Gianni Infantino",
  "JAKEPAUL": "Jake Paul",
  "JEFFERSON": "Philip Jefferson",
  "JENSEN": "Jensen Huang",
  "JOHNSON": "Mike Johnson",
  "JPOW": "Jerome Powell",
  "KAMALA": "Kamala Harris",
  "KARDASHIAN": "Kim Kardashian",
  "KARP": "Alex Karp",
  "KIMMEL": "Jimmy Kimmel",
  "KING": "King Charles III",
  "KIRK": "Charlie Kirk",
  "KLOBUCHAR": "Amy Klobuchar",
  "LAGARDE": "Christine Lagarde",
  "LAMMY": "David Lammy",
  "LASTWORD": "The Last Word",
  "LATENIGHT": "Late Night",
  "LEAVITT": "Karoline Leavitt",
  "LEAVITTMENTIONDURATION": "Karoline Leavitt",
  "LEAVITTSMF": "Karoline Leavitt",
  "LEBRON": "LeBron James",
  "LOPEZ": "Jennifer Lopez",
  "LUTNICK": "Howard Lutnick",
  "LUTNICKFTN": "Howard Lutnick",
  "MABORO": "Marco Rubio",
  "MADDOW": "Rachel Maddow",
  "MAHER": "Bill Maher",
  "MAMDANI": "Mahmoud Mamdani",
  "MELANIA": "Melania Trump",
  "MINAJ": "Nicki Minaj",
  "MIRAN": "Stephen Miran",
  "MLB": "MLB",
  "MM": "Mad Money",
  "MNF": "Monday Night Football",
  "MRBEAST": "MrBeast",
  "MTG": "Marjorie Taylor Greene",
  "MTP": "Meet the Press",
  "NADAL": "Rafael Nadal",
  "NADLER": "Jerry Nadler",
  "NBA": "NBA",
  "NCAAB": "NCAA Basketball",
  "NETANYAHU": "Benjamin Netanyahu",
  "NEWSNATION": "NewsNation",
  "NEWSOM": "Gavin Newsom",
  "NYCMAYORDEBATE": "NYC Mayor Debate",
  "NYCMDEB": "NYC Mayor Debate",
  "OSCAR": "Oscars",
  "OSCARS": "Oscars",
  "PAUL": "Jake Paul",
  "PELOSI": "Nancy Pelosi",
  "PRES": "Donald Trump",
  "POWELL": "Jerome Powell",
  "PROBST": "Jeff Probst",
  "PSAKI": "Jen Psaki",
  "RASKIN": "Jamie Raskin",
  "REEVES": "Keanu Reeves",
  "REIDOUT": "The ReidOut",
  "ROG": "Joe Rogan",
  "ROGAN": "Joe Rogan",
  "RUBIO": "Marco Rubio",
  "SB": "Super Bowl",
  "SCHIFF": "Adam Schiff",
  "SCHUMER": "Chuck Schumer",
  "SCOTUS": "SCOTUS",
  "SCOTT": "Tim Scott",
  "SECPRESS": "White House Press Secretary",
  "SHAQ": "Shaquille O'Neal",
  "SHAPIRO": "Ben Shapiro",
  "SHIRLEY": "Nick Shirley",
  "SNOOP": "Snoop Dogg",
  "SNF": "Sunday Night Football",
  "SNL": "Saturday Night Live",
  "SOTU": "State of the Union",
  "SOUTHPARK": "South Park",
  "SPANBERGER": "Abigail Spanberger",
  "STARMER": "Keir Starmer",
  "STEFANIK": "Elise Stefanik",
  "SURVIVOR": "Survivor",
  "SWALWELL": "Eric Swalwell",
  "SWIFT": "Taylor Swift",
  "TALARICO": "James Talarico",
  "TBPN": "TBPN Podcast",
  "THREADGUY": "ThreadGuy",
  "TNF": "Thursday Night Football",
  "TONIGHTSHOW": "The Tonight Show",
  "TRUMP": "Donald Trump",
  "UN": "United Nations",
  "VANCE": "JD Vance",
  "VIEW": "The View",
  "VIVEK": "Vivek Ramaswamy",
  "VLADTENEV": "Vlad Tenev",
  "WALES": "Jimmy Wales",
  "WALLER": "Christopher Waller",
  "WALZ": "Tim Walz",
  "WARREN": "Elizabeth Warren",
  "WEF": "World Economic Forum",
  "WHITMER": "Gretchen Whitmer",
  "WWDC": "WWDC",
  "ZAKARIA": "Fareed Zakaria",
  "ZELENS": "Volodymyr Zelenskyy",
  "ZIWE": "Ziwe Fumudoh",
  "ZUCK": "Mark Zuckerberg",
};

// Tickers that represent shows/events — subject should be extracted from the title, not the ticker
const SHOW_TICKERS = new Set([
  "60MIN", "SNL", "FOXNEWS", "MTP", "MM", "GAMEDAY",
  "LATENIGHT", "FACETHENATION", "NEWSNATION", "DWTS", "DOGSHOW",
  "CMAWARDS", "AWARDSSHOW", "COLLEGEFOOTBALL", "MLB", "NBA", "NCAAB",
  "BILATERALMEETING", "CANADIANDEBATE", "ECB", "FEDGOV", "FED",
  "NYCMAYORDEBATE", "NYCMDEB", "SCOTUS", "UN", "WEF", "SOTU",
  "SOUTHPARK", "SURVIVOR", "WWDC", "REIDOUT", "LASTWORD", "VIEW",
  "TONIGHTSHOW", "CONGRESS", "GOVERNOR", "CULTURE", "TBPN", "THREADGUY",
]);

// Extract person's full name from market rules_primary text
// Rules often start with "Will [FirstName LastName] say..."
function extractPersonFromRules(rulesText: string): string | null {
  if (!rulesText) return null;
  const match = rulesText.match(/^Will\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\s+(?:say|mention|use)/i);
  if (match) return match[1].trim();
  return null;
}

function extractPersonFromTitle(title: string): string | null {
  const patterns = [
    /what will (.+?) say/i,
    /what will (.+?) mention/i,
    /during (.+?)[''\u2019]s/i,
  ];
  for (const p of patterns) {
    const m = title.match(p);
    if (m) {
      return m[1].trim().split(/\s+/).map((w: string) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join(" ");
    }
  }
  return null;
}

function extractSubjectFromTicker(seriesTicker: string, eventTitle: string, rulesText?: string): string {
  const tickerMatch = seriesTicker.match(/^KX(.+?)MENTION$/i);
  if (tickerMatch) {
    const key = tickerMatch[1].toUpperCase();

    // If this is a show ticker, extract the person from the title first
    if (SHOW_TICKERS.has(key)) {
      const person = extractPersonFromTitle(eventTitle);
      if (person) {
        // Check if the extracted name (e.g. "Powell") maps to a full name (e.g. "Jerome Powell")
        const personKey = person.toUpperCase().replace(/\s+/g, "");
        if (TICKER_NAME_MAP[personKey]) return TICKER_NAME_MAP[personKey];
        // Also check if it's a single last name that matches a map entry
        const words = person.split(/\s+/);
        if (words.length === 1) {
          const lastNameKey = words[0].toUpperCase();
          if (TICKER_NAME_MAP[lastNameKey]) return TICKER_NAME_MAP[lastNameKey];
        }
        return person;
      }
      // Try rules_primary fallback for full name
      if (rulesText) {
        const rulesPerson = extractPersonFromRules(rulesText);
        if (rulesPerson) {
          const rpKey = rulesPerson.toUpperCase().replace(/\s+/g, "");
          if (TICKER_NAME_MAP[rpKey]) return TICKER_NAME_MAP[rpKey];
          return rulesPerson;
        }
      }
      // If we can't find a person, use the show name from the map or title-case
      if (TICKER_NAME_MAP[key]) return TICKER_NAME_MAP[key];
      const raw = tickerMatch[1].toLowerCase();
      return raw.charAt(0).toUpperCase() + raw.slice(1);
    }

    if (TICKER_NAME_MAP[key]) return TICKER_NAME_MAP[key];

    // For unknown tickers, try rules_primary for full name before title-casing
    if (rulesText) {
      const rulesPerson = extractPersonFromRules(rulesText);
      if (rulesPerson) return rulesPerson;
    }

    // Title-case the raw ticker as fallback
    const raw = tickerMatch[1].toLowerCase();
    return raw.charAt(0).toUpperCase() + raw.slice(1);
  }

  // Fallback: parse from title
  const person = extractPersonFromTitle(eventTitle);
  if (person) return person;
  return "Unknown";
}

function extractTicker(url: string): { eventTicker: string; seriesTicker: string } {
  // Kalshi URLs: /markets/{series_ticker}/{slug}/{event_ticker}
  const urlMatch = url.match(/markets\/([^\/]+)\/[^\/]+\/([^\/\?\#]+)/i);
  if (urlMatch) return { seriesTicker: urlMatch[1].toUpperCase(), eventTicker: urlMatch[2].toUpperCase() };

  const twoPartMatch = url.match(/markets\/([^\/]+)\/([^\/\?\#]+)/i);
  if (twoPartMatch) return { seriesTicker: twoPartMatch[1].toUpperCase(), eventTicker: twoPartMatch[2].toUpperCase() };

  const ticker = url.trim().toUpperCase();
  return { eventTicker: ticker, seriesTicker: ticker };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { url } = await req.json();
    if (!url) {
      return new Response(JSON.stringify({ error: "URL is required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { eventTicker, seriesTicker } = extractTicker(url);
    console.log("Tickers:", { eventTicker, seriesTicker });

    // Use the markets API which returns full market objects with all fields
    let markets: any[] = [];
    let cursor = "";
    
    // Paginate to get all markets
    do {
      const marketsUrl = `https://api.elections.kalshi.com/trade-api/v2/markets?event_ticker=${eventTicker}&limit=200${cursor ? `&cursor=${cursor}` : ""}`;
      console.log("Fetching:", marketsUrl);
      const resp = await fetch(marketsUrl);
      const data = await resp.json();
      if (data.markets?.length) {
        markets = markets.concat(data.markets);
      }
      cursor = data.cursor || "";
    } while (cursor);

    // If no markets, try the event API
    if (markets.length === 0) {
      const eventUrl = `https://api.elections.kalshi.com/trade-api/v2/events/${eventTicker}?with_nested_markets=true`;
      const resp = await fetch(eventUrl);
      const data = await resp.json();
      if (data.event?.markets?.length) {
        markets = data.event.markets;
      }
    }

    if (markets.length === 0) {
      return new Response(
        JSON.stringify({ error: `No markets found for: ${eventTicker}` }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Log first market for debugging
    const sample = markets[0];
    console.log("Market fields:", JSON.stringify({
      title: sample.title,
      subtitle: sample.subtitle,
      yes_sub_title: sample.yes_sub_title,
      no_sub_title: sample.no_sub_title,
      ticker: sample.ticker,
      result: sample.result,
      yes_bid: sample.yes_bid,
      no_bid: sample.no_bid,
      last_price: sample.last_price,
    }));

    // Get event title from the event API
    let eventTitle = "";
    const eventResp = await fetch(`https://api.elections.kalshi.com/trade-api/v2/events/${eventTicker}`);
    const eventData = await eventResp.json();
    eventTitle = eventData.event?.title || sample.title || eventTicker;

    // Use ticker-based subject resolution with rules_primary fallback
    const rulesText = sample.rules_primary || "";
    const subject = extractSubjectFromTicker(seriesTicker, eventTitle, rulesText);
    console.log("Resolved subject:", subject, "from ticker:", seriesTicker);

    // Event date
    const eventDate = (sample.close_time || sample.expiration_time || new Date().toISOString()).split("T")[0];

    // Build Supabase client
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    // Upsert subject
    let { data: existingSubject } = await supabase
      .from("subjects").select("id").eq("name", subject).maybeSingle();
    if (!existingSubject) {
      const { data: ns, error } = await supabase
        .from("subjects").insert({ name: subject }).select("id").single();
      if (error) throw error;
      existingSubject = ns;
    }

    // Upsert mention event (no duplicates)
    const { data: event, error: evErr } = await supabase
      .from("mention_events")
      .upsert({
        subject_id: existingSubject!.id,
        kalshi_event_ticker: eventTicker,
        series_ticker: seriesTicker,
        title: eventTitle,
        event_date: eventDate,
      }, { onConflict: "kalshi_event_ticker" })
      .select().single();
    if (evErr) throw evErr;

    // Parse phrase markets
    const phraseRows = markets.map((m: any) => {
      // yes_sub_title contains the phrase directly (e.g. "Hockey")
      let phraseText = m.yes_sub_title || m.no_sub_title || "";
      
      // If empty, try quoted text from title/subtitle
      if (!phraseText) {
        for (const field of [m.subtitle, m.title]) {
          if (!field) continue;
          const match = field.match(/['''"""\u2018\u2019\u201C\u201D]([^'''"""\u2018\u2019\u201C\u201D]+)['''"""\u2018\u2019\u201C\u201D]/);
          if (match) { phraseText = match[1]; break; }
        }
      }
      
      // Fallback: ticker suffix
      if (!phraseText && m.ticker) {
        const parts = m.ticker.split("-");
        if (parts.length >= 3) phraseText = parts.slice(2).join("-");
      }
      
      if (!phraseText) phraseText = m.ticker || "UNKNOWN";

      // Prices — Kalshi returns cents (0-99)
      const yesBid = m.yes_bid ?? 0;
      const noBid = m.no_bid ?? 0;

      // Determine mention: only trust settled results or meaningful bids
      let wasMentioned = false;
      if (m.result === "yes") wasMentioned = true;
      else if (m.result === "no") wasMentioned = false;
      else if (m.status === "finalized" || m.status === "settled") {
        wasMentioned = yesBid > 50;
      }

      return {
        mention_event_id: event.id,
        phrase_text: phraseText.toUpperCase(),
        was_mentioned: wasMentioned,
        yes_bid: yesBid / 100,
        no_bid: noBid / 100,
        kalshi_ticker: m.ticker || "",
      };
    });

    const { error: phErr } = await supabase
      .from("phrase_markets")
      .upsert(phraseRows, { onConflict: "mention_event_id,kalshi_ticker" });
    if (phErr) throw phErr;

    // Query all phrases for this event
    const { data: allPhrases, error: fetchErr } = await supabase
      .from("phrase_markets")
      .select()
      .eq("mention_event_id", event.id);
    if (fetchErr) throw fetchErr;

    return new Response(
      JSON.stringify({ success: true, event, subject, phrases: allPhrases, phrasesCount: phraseRows.length }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err: any) {
    console.error("Error:", err);
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
