import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const KALSHI_BASE = "https://api.elections.kalshi.com/trade-api/v2";

// How many series to process per invocation to avoid timeout
const BATCH_SIZE = 5;

const SEED_SERIES = [
  "KXTRUMPMENTION", "KXBIDENMENTION", "KXHOCHULMENTION",
  "KXJENSENMENTION", "KXSECPRESSMENTION", "KXMABOROMENTION",
  "KXPELOSIMENTION", "KXDESANTISMENTION", "KXNEWSOMMENTION",
  "KXHARRISPMENTION", "KXZELENSMENTION", "KXELONMENTION",
  "KXSTARMERMENTION", "KXPROBSTMENTION", "KXROGMENTION",
];

async function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function fetchWithRetry(url: string, retries = 3): Promise<Response> {
  for (let i = 0; i < retries; i++) {
    const resp = await fetch(url);
    if (resp.status === 429) {
      console.log(`Rate limited, waiting ${(i + 1) * 2}s...`);
      await sleep((i + 1) * 2000);
      continue;
    }
    return resp;
  }
  throw new Error(`Rate limited after ${retries} retries: ${url}`);
}

async function discoverAllMentionSeries(): Promise<string[]> {
  const series = new Set(SEED_SERIES);
  const categories = ["Politics", "Economics", "Entertainment", "Culture", "Sports", "Technology", "Science", "World"];

  for (const category of categories) {
    try {
      const url = `${KALSHI_BASE}/series?category=${encodeURIComponent(category)}&limit=1000`;
      const resp = await fetchWithRetry(url);
      if (!resp.ok) continue;
      const data = await resp.json();
      for (const s of data.series || []) {
        const ticker = (s.ticker || "").toUpperCase();
        if (ticker.includes("MENTION")) {
          series.add(ticker);
        }
      }
    } catch (err) {
      console.error(`Category ${category} scan error:`, err);
    }
    await sleep(200);
  }

  // Also scan open events
  try {
    const url = `${KALSHI_BASE}/events?limit=200&status=open`;
    const resp = await fetchWithRetry(url);
    if (resp.ok) {
      const data = await resp.json();
      for (const e of data.events || []) {
        const ticker = (e.series_ticker || e.event_ticker || "").toUpperCase();
        if (ticker.includes("MENTION")) {
          const seriesMatch = ticker.match(/^(KX\w+MENTION)/);
          if (seriesMatch) series.add(seriesMatch[1]);
        }
      }
    }
  } catch (err) {
    console.error("Events scan error:", err);
  }

  return [...series].sort();
}

// Known ticker-to-name mappings for multi-word or non-obvious subjects
const TICKER_NAME_MAP: Record<string, string> = {
  "60MIN": "60 Minutes",
  "ACOOPER": "Anderson Cooper",
  "ACKMAN": "Bill Ackman",
  "ALTHOFF": "Judson Althoff",
  "ALTMAN": "Sam Altman",
  "AMODEI": "Dario Amodei",
  "AOC": "Alexandria Ocasio-Cortez",
  "ARMSTRONG": "Brian Armstrong",
  "AWARD": "Awards Show",
  "BANNON": "Steve Bannon",
  "BARKLEY": "Charles Barkley",
  "BARR": "Bill Barr",
  "BELL": "Kristen Bell",
  "BENIOFF": "Marc Benioff",
  "BERNIE": "Bernie Sanders",
  "BESSENTMTP": "Scott Bessent",
  "BETO": "Beto O'Rourke",
  "BIDEN": "Joe Biden",
  "BONGINO": "Dan Bongino",
  "BUSH": "George W. Bush",
  "CANDEB": "Canadian Debate",
  "CARLSON": "Tucker Carlson",
  "CENA": "John Cena",
  "CFB": "College Football",
  "CMA": "CMA Awards",
  "COLBERT": "Stephen Colbert",
  "COMER": "James Comer",
  "CONAN": "Conan O'Brien",
  "CONGRESS": "Congress",
  "COOPER": "Anderson Cooper",
  "COSTA": "António Costa",
  "CROCKETT": "Jasmine Crockett",
  "CRUZ": "Ted Cruz",
  "CULTURE": "Culture",
  "CUOMO": "Chris Cuomo",
  "DESANTIS": "Ron DeSantis",
  "DILLON": "Luke Dillon",
  "DIMON": "Jamie Dimon",
  "DOGSHOW": "Dog Show",
  "DWTS": "Dancing with the Stars",
  "ELON": "Elon Musk",
  "FINK": "Larry Fink",
  "FOXNEWS": "Fox News",
  "FRANKLIN": "James Franklin",
  "FREY": "Jacob Frey",
  "FTN": "Face the Nation",
  "GAETZ": "Matt Gaetz",
  "GAMEDAY": "GameDay",
  "GLASER": "Nikki Glaser",
  "GOVERNOR": "Governor",
  "GREEN": "Josh Green",
  "GRIFFIN": "Ken Griffin",
  "HALEY": "Nikki Haley",
  "HARRISP": "Kamala Harris",
  "HART": "Kevin Hart",
  "HEGSETH": "Pete Hegseth",
  "HOCHUL": "Kathy Hochul",
  "HOMAN": "Tom Homan",
  "HUBERMAN": "Andrew Huberman",
  "INFANTINO": "Gianni Infantino",
  "JAKEPAUL": "Jake Paul",
  "JEFFERSON": "Philip Jefferson",
  "JENSEN": "Jensen Huang",
  "JOHNSON": "Mike Johnson",
  "JPOW": "Jerome Powell",
  "KAMALA": "Kamala Harris",
  "KARDASHIAN": "Kim Kardashian",
  "KARP": "Alex Karp",
  "KIMMEL": "Jimmy Kimmel",
  "KING": "King Charles III",
  "KIRK": "Charlie Kirk",
  "KLOBUCHAR": "Amy Klobuchar",
  "LAGARDE": "Christine Lagarde",
  "LAMMY": "David Lammy",
  "LASTWORD": "The Last Word",
  "LATENIGHT": "Late Night",
  "LEAVITT": "Karoline Leavitt",
  "LEAVITTMENTIONDURATION": "Karoline Leavitt",
  "LEAVITTSMF": "Karoline Leavitt",
  "LEBRON": "LeBron James",
  "LOPEZ": "Jennifer Lopez",
  "LUTNICK": "Howard Lutnick",
  "LUTNICKFTN": "Howard Lutnick",
  "MABORO": "Marco Rubio",
  "MADDOW": "Rachel Maddow",
  "MAHER": "Bill Maher",
  "MAMDANI": "Mahmoud Mamdani",
  "MELANIA": "Melania Trump",
  "MINAJ": "Nicki Minaj",
  "MIRAN": "Stephen Miran",
  "MLB": "MLB",
  "MM": "Mad Money",
  "MNF": "Monday Night Football",
  "MRBEAST": "MrBeast",
  "MTG": "Marjorie Taylor Greene",
  "MTP": "Meet the Press",
  "NADAL": "Rafael Nadal",
  "NADLER": "Jerry Nadler",
  "NBA": "NBA",
  "NCAAB": "NCAA Basketball",
  "NETANYAHU": "Benjamin Netanyahu",
  "NEWSNATION": "NewsNation",
  "NEWSOM": "Gavin Newsom",
  "NYCMAYORDEBATE": "NYC Mayor Debate",
  "NYCMDEB": "NYC Mayor Debate",
  "OSCAR": "Oscars",
  "OSCARS": "Oscars",
  "PAUL": "Jake Paul",
  "PELOSI": "Nancy Pelosi",
  "PRES": "Donald Trump",
  "POWELL": "Jerome Powell",
  "PROBST": "Jeff Probst",
  "PSAKI": "Jen Psaki",
  "RASKIN": "Jamie Raskin",
  "REEVES": "Keanu Reeves",
  "REIDOUT": "The ReidOut",
  "ROG": "Joe Rogan",
  "ROGAN": "Joe Rogan",
  "RUBIO": "Marco Rubio",
  "SB": "Super Bowl",
  "SCHIFF": "Adam Schiff",
  "SCHUMER": "Chuck Schumer",
  "SCOTUS": "SCOTUS",
  "SCOTT": "Tim Scott",
  "SECPRESS": "White House Press Secretary",
  "SHAQ": "Shaquille O'Neal",
  "SHAPIRO": "Ben Shapiro",
  "SHIRLEY": "Nick Shirley",
  "SNOOP": "Snoop Dogg",
  "SNF": "Sunday Night Football",
  "SNL": "Saturday Night Live",
  "SOTU": "State of the Union",
  "SOUTHPARK": "South Park",
  "SPANBERGER": "Abigail Spanberger",
  "STARMER": "Keir Starmer",
  "STEFANIK": "Elise Stefanik",
  "SURVIVOR": "Survivor",
  "SWALWELL": "Eric Swalwell",
  "SWIFT": "Taylor Swift",
  "TALARICO": "James Talarico",
  "TBPN": "TBPN Podcast",
  "THREADGUY": "ThreadGuy",
  "TNF": "Thursday Night Football",
  "TONIGHTSHOW": "The Tonight Show",
  "TRUMP": "Donald Trump",
  "UN": "United Nations",
  "VANCE": "JD Vance",
  "VIEW": "The View",
  "VIVEK": "Vivek Ramaswamy",
  "VLADTENEV": "Vlad Tenev",
  "WALES": "Jimmy Wales",
  "WALLER": "Christopher Waller",
  "WALZ": "Tim Walz",
  "WARREN": "Elizabeth Warren",
  "WEF": "World Economic Forum",
  "WHITMER": "Gretchen Whitmer",
  "WWDC": "WWDC",
  "ZAKARIA": "Fareed Zakaria",
  "ZELENS": "Volodymyr Zelenskyy",
  "ZIWE": "Ziwe Fumudoh",
  "ZUCK": "Mark Zuckerberg",
};

// Tickers that represent shows/events — subject should be extracted from the title, not the ticker
const SHOW_TICKERS = new Set([
  "60MIN", "SNL", "FOXNEWS", "MTP", "MM", "GAMEDAY",
  "LATENIGHT", "FACETHENATION", "NEWSNATION", "DWTS", "DOGSHOW",
  "CMAWARDS", "AWARDSSHOW", "COLLEGEFOOTBALL", "MLB", "NBA", "NCAAB",
  "BILATERALMEETING", "CANADIANDEBATE", "ECB", "FEDGOV", "FED",
  "NYCMAYORDEBATE", "NYCMDEB", "SCOTUS", "UN", "WEF", "SOTU",
  "SOUTHPARK", "SURVIVOR", "WWDC", "REIDOUT", "LASTWORD", "VIEW",
  "TONIGHTSHOW", "CONGRESS", "GOVERNOR", "CULTURE", "TBPN", "THREADGUY",
]);

// Extract person's full name from market rules_primary text
function extractPersonFromRules(rulesText: string): string | null {
  if (!rulesText) return null;
  const match = rulesText.match(/^Will\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\s+(?:say|mention|use)/i);
  if (match) return match[1].trim();
  return null;
}

function extractPersonFromTitle(title: string): string | null {
  const patterns = [
    /what will (.+?) say/i,
    /what will (.+?) mention/i,
    /during (.+?)[''\u2019]s/i,
  ];
  for (const p of patterns) {
    const m = title.match(p);
    if (m) {
      return m[1].trim().split(/\s+/).map((w: string) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join(" ");
    }
  }
  return null;
}

function extractSubject(title: string, seriesTicker: string, rulesText?: string): string {
  const tickerMatch = seriesTicker.match(/^KX(.+?)MENTION$/i);
  if (tickerMatch) {
    const key = tickerMatch[1].toUpperCase();

    // If this is a show ticker, extract the person from the title first
    if (SHOW_TICKERS.has(key)) {
      const person = extractPersonFromTitle(title);
      if (person) {
        const personKey = person.toUpperCase().replace(/\s+/g, "");
        if (TICKER_NAME_MAP[personKey]) return TICKER_NAME_MAP[personKey];
        const words = person.split(/\s+/);
        if (words.length === 1) {
          const lastNameKey = words[0].toUpperCase();
          if (TICKER_NAME_MAP[lastNameKey]) return TICKER_NAME_MAP[lastNameKey];
        }
        return person;
      }
      // Try rules_primary fallback
      if (rulesText) {
        const rulesPerson = extractPersonFromRules(rulesText);
        if (rulesPerson) {
          const rpKey = rulesPerson.toUpperCase().replace(/\s+/g, "");
          if (TICKER_NAME_MAP[rpKey]) return TICKER_NAME_MAP[rpKey];
          return rulesPerson;
        }
      }
      if (TICKER_NAME_MAP[key]) return TICKER_NAME_MAP[key];
      const raw = tickerMatch[1].toLowerCase();
      return raw.charAt(0).toUpperCase() + raw.slice(1);
    }

    if (TICKER_NAME_MAP[key]) return TICKER_NAME_MAP[key];

    // For unknown tickers, try rules_primary before title-casing
    if (rulesText) {
      const rulesPerson = extractPersonFromRules(rulesText);
      if (rulesPerson) return rulesPerson;
    }

    const raw = tickerMatch[1].toLowerCase();
    return raw.charAt(0).toUpperCase() + raw.slice(1);
  }

  // Last resort: parse from title
  const person = extractPersonFromTitle(title);
  if (person) return person;
  return "Unknown";
}

async function processSeries(seriesTicker: string, supabase: any): Promise<{ processed: number; errors: number }> {
  let totalProcessed = 0;
  let totalErrors = 0;

  try {
    let events: any[] = [];
    let cursor = "";
    do {
      const url = `${KALSHI_BASE}/events?series_ticker=${seriesTicker}&limit=200${cursor ? `&cursor=${cursor}` : ""}`;
      const resp = await fetchWithRetry(url);
      if (!resp.ok) break;
      const data = await resp.json();
      events = events.concat(data.events || []);
      cursor = data.cursor || "";
    } while (cursor);

    if (events.length === 0) return { processed: 0, errors: 0 };

    // Resolve subject using first event's title + market rules as fallback
    let subjectResolved = false;
    let existingSubject: any = null;

    for (const event of events) {
      try {
        const eventTicker = (event.event_ticker || event.ticker || "").toUpperCase();
        if (!eventTicker) continue;

        let markets: any[] = [];
        let mCursor = "";
        do {
          const url = `${KALSHI_BASE}/markets?event_ticker=${eventTicker}&limit=200${mCursor ? `&cursor=${mCursor}` : ""}`;
          const resp = await fetchWithRetry(url);
          if (!resp.ok) break;
          const data = await resp.json();
          if (data.markets?.length) markets = markets.concat(data.markets);
          mCursor = data.cursor || "";
        } while (mCursor);

        if (markets.length === 0) continue;

        // Resolve subject on first event with markets (has rules_primary)
        if (!subjectResolved) {
          const rulesText = markets[0].rules_primary || "";
          const subject = extractSubject(events[0].title || "", seriesTicker, rulesText);
          let { data: subj } = await supabase
            .from("subjects").select("id").eq("name", subject).maybeSingle();
          if (!subj) {
            const { data: ns, error } = await supabase
              .from("subjects").insert({ name: subject }).select("id").single();
            if (error) { console.error("Subject error:", error); continue; }
            subj = ns;
          }
          existingSubject = subj;
          subjectResolved = true;
        }

        if (!existingSubject) continue;

        const eventDate = (markets[0].close_time || markets[0].expiration_time || new Date().toISOString()).split("T")[0];

        const { data: ev, error: evErr } = await supabase
          .from("mention_events")
          .upsert({
            subject_id: existingSubject!.id,
            kalshi_event_ticker: eventTicker,
            series_ticker: seriesTicker,
            title: event.title || eventTicker,
            event_date: eventDate,
          }, { onConflict: "kalshi_event_ticker" })
          .select().single();
        if (evErr) { console.error("Event upsert error:", evErr); continue; }

        const phraseRows = markets.map((m: any) => {
          let phraseText = m.yes_sub_title || m.no_sub_title || "";
          if (!phraseText) {
            for (const field of [m.subtitle, m.title]) {
              if (!field) continue;
              const match = field.match(/['''"""\u2018\u2019\u201C\u201D]([^'''"""\u2018\u2019\u201C\u201D]+)['''"""\u2018\u2019\u201C\u201D]/);
              if (match) { phraseText = match[1]; break; }
            }
          }
          if (!phraseText && m.ticker) {
            const parts = m.ticker.split("-");
            if (parts.length >= 3) phraseText = parts.slice(2).join("-");
          }
          if (!phraseText) phraseText = m.ticker || "UNKNOWN";

          const yesBid = m.yes_bid ?? 0;
          let wasMentioned = false;
          if (m.result === "yes") wasMentioned = true;
          else if (m.result === "no") wasMentioned = false;
          else if (m.status === "finalized" || m.status === "settled") {
            wasMentioned = yesBid > 50;
          }

          return {
            mention_event_id: ev.id,
            phrase_text: phraseText.toUpperCase(),
            was_mentioned: wasMentioned,
            yes_bid: yesBid / 100,
            no_bid: (m.no_bid ?? 0) / 100,
            kalshi_ticker: m.ticker || "",
          };
        });

        await supabase
          .from("phrase_markets")
          .upsert(phraseRows, { onConflict: "mention_event_id,kalshi_ticker" });

        totalProcessed++;
        await sleep(150);
      } catch (err) {
        console.error("Event processing error:", err);
        totalErrors++;
      }
    }
  } catch (err) {
    console.error(`Series ${seriesTicker} error:`, err);
    totalErrors++;
  }

  return { processed: totalProcessed, errors: totalErrors };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body = await req.json().catch(() => ({}));
    const batchIndex = body.batch ?? 0;
    const discoverOnly = body.discover_only ?? false;
    const specificTickers: string[] | undefined = body.tickers;

    console.log(`Starting discover-mentions, batch=${batchIndex}, discover_only=${discoverOnly}, tickers=${specificTickers?.length ?? 'auto'}`);

    let allSeries: string[];
    if (specificTickers && specificTickers.length > 0) {
      allSeries = specificTickers;
    } else {
      allSeries = await discoverAllMentionSeries();
    }
    console.log(`Total series: ${allSeries.length}`);

    if (discoverOnly) {
      return new Response(
        JSON.stringify({ series: allSeries, total: allSeries.length }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const start = specificTickers ? 0 : batchIndex * BATCH_SIZE;
    const batchSize = specificTickers ? specificTickers.length : BATCH_SIZE;
    const batch = allSeries.slice(start, start + batchSize);
    const hasMore = !specificTickers && (start + BATCH_SIZE < allSeries.length);

    if (batch.length === 0) {
      return new Response(
        JSON.stringify({ success: true, message: "All batches complete", total_series: allSeries.length }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`Processing batch ${batchIndex}: ${batch.join(", ")}`);

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    let totalProcessed = 0;
    let totalErrors = 0;

    for (const seriesTicker of batch) {
      const result = await processSeries(seriesTicker, supabase);
      totalProcessed += result.processed;
      totalErrors += result.errors;
      console.log(`${seriesTicker}: ${result.processed} events, ${result.errors} errors`);
    }

    return new Response(
      JSON.stringify({
        success: true,
        batch: batchIndex,
        series_processed: batch,
        events_processed: totalProcessed,
        errors: totalErrors,
        has_more: hasMore,
        next_batch: hasMore ? batchIndex + 1 : null,
        total_series: allSeries.length,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err: any) {
    console.error("Discovery error:", err);
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
