import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const KALSHI_API = "https://api.elections.kalshi.com/trade-api/v2";

async function fetchAllSeriesEvents(seriesTicker: string): Promise<any[]> {
  let events: any[] = [];
  let cursor = "";
  do {
    const url = `${KALSHI_API}/events?series_ticker=${seriesTicker}&limit=200${cursor ? `&cursor=${cursor}` : ""}`;
    console.log("Fetching events:", url);
    const resp = await fetch(url);
    const data = await resp.json();
    if (data.events?.length) events = events.concat(data.events);
    cursor = data.cursor || "";
  } while (cursor);
  return events;
}

async function fetchEventMarkets(eventTicker: string): Promise<any[]> {
  let markets: any[] = [];
  let cursor = "";
  do {
    const url = `${KALSHI_API}/markets?event_ticker=${eventTicker}&limit=200${cursor ? `&cursor=${cursor}` : ""}`;
    const resp = await fetch(url);
    const data = await resp.json();
    if (data.markets?.length) markets = markets.concat(data.markets);
    cursor = data.cursor || "";
  } while (cursor);
  return markets;
}

function extractPhrase(m: any): string {
  let phraseText = m.yes_sub_title || m.no_sub_title || "";
  if (!phraseText) {
    for (const field of [m.subtitle, m.title]) {
      if (!field) continue;
      const match = field.match(/['''"""\u2018\u2019\u201C\u201D]([^'''"""\u2018\u2019\u201C\u201D]+)['''"""\u2018\u2019\u201C\u201D]/);
      if (match) { phraseText = match[1]; break; }
    }
  }
  if (!phraseText && m.ticker) {
    const parts = m.ticker.split("-");
    if (parts.length >= 3) phraseText = parts.slice(2).join("-");
  }
  return (phraseText || m.ticker || "UNKNOWN").toUpperCase();
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { phrase, series_ticker, subject_id } = await req.json();
    if (!phrase || !series_ticker || !subject_id) {
      return new Response(
        JSON.stringify({ error: "phrase, series_ticker, and subject_id are required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("Backfilling:", { phrase, series_ticker });

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    // Get all events already tracked for this series
    const { data: existingEvents } = await supabase
      .from("mention_events")
      .select("kalshi_event_ticker")
      .eq("series_ticker", series_ticker);

    const existingTickers = new Set(
      (existingEvents || []).map((e) => e.kalshi_event_ticker)
    );

    // Fetch all events in the series from Kalshi
    const allEvents = await fetchAllSeriesEvents(series_ticker);
    console.log(`Found ${allEvents.length} events in series, ${existingTickers.size} already tracked`);

    // Filter to events not yet tracked
    const newEvents = allEvents.filter(
      (e) => !existingTickers.has(e.event_ticker)
    );

    let newPhraseMatches = 0;
    let eventsProcessed = 0;

    // Process each new event
    for (const kalshiEvent of newEvents) {
      const markets = await fetchEventMarkets(kalshiEvent.event_ticker);
      if (!markets.length) continue;

      // Check if any market in this event contains our target phrase
      const matchingMarkets = markets.filter(
        (m) => extractPhrase(m) === phrase
      );

      // Even if the phrase wasn't in this event, we might want to record it
      // But for efficiency, only store events that had this phrase
      if (matchingMarkets.length === 0) {
        // Still check: sometimes all markets should be stored for the event
        // For now, skip events without the target phrase
        continue;
      }

      // Get event date
      const eventDate = (markets[0].close_time || markets[0].expiration_time || new Date().toISOString()).split("T")[0];

      // Create the mention event
      const { data: event, error: evErr } = await supabase
        .from("mention_events")
        .upsert({
          subject_id,
          kalshi_event_ticker: kalshiEvent.event_ticker,
          series_ticker,
          title: kalshiEvent.title || kalshiEvent.event_ticker,
          event_date: eventDate,
        }, { onConflict: "kalshi_event_ticker" })
        .select()
        .single();

      if (evErr) {
        console.error("Error inserting event:", evErr);
        continue;
      }

      // Insert ALL phrase markets for this event (not just the matching one)
      const phraseRows = markets.map((m: any) => {
        const yesBid = m.yes_bid ?? 0;
        const noBid = m.no_bid ?? 0;
        let wasMentioned = false;
        if (m.result === "yes") wasMentioned = true;
        else if (m.result === "no") wasMentioned = false;
        else if (m.status === "finalized" || m.status === "settled") {
          wasMentioned = yesBid > 50;
        }

        return {
          mention_event_id: event.id,
          phrase_text: extractPhrase(m),
          was_mentioned: wasMentioned,
          yes_bid: yesBid / 100,
          no_bid: noBid / 100,
          kalshi_ticker: m.ticker || "",
        };
      });

      const { error: phErr } = await supabase
        .from("phrase_markets")
        .upsert(phraseRows, { onConflict: "mention_event_id,kalshi_ticker" });

      if (phErr) console.error("Error inserting phrases:", phErr);
      else {
        newPhraseMatches += matchingMarkets.length;
        eventsProcessed++;
      }
    }

    console.log(`Backfill complete: ${eventsProcessed} new events, ${newPhraseMatches} phrase matches`);

    return new Response(
      JSON.stringify({
        success: true,
        newEvents: eventsProcessed,
        newPhraseMatches,
        totalSeriesEvents: allEvents.length,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err: any) {
    console.error("Backfill error:", err);
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
